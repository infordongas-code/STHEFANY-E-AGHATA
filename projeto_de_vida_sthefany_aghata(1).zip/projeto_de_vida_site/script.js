const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');

menuToggle.addEventListener('click', () => {
  nav.classList.toggle('aberto');
  menuToggle.textContent = nav.classList.contains('aberto') ? '✕' : '☰';
});

nav.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    nav.classList.remove('aberto');
    menuToggle.textContent = '☰';
  });
});

const tarefas = [...document.querySelectorAll('[data-task]')];
const barra = document.getElementById('barraProgresso');
const texto = document.getElementById('progressoTexto');

function atualizarProgresso() {
  const concluidas = tarefas.filter(t => t.checked).length;
  barra.style.width = `${(concluidas / tarefas.length) * 100}%`;
  texto.textContent = `${concluidas} de ${tarefas.length} etapas`;
  tarefas.forEach(t => localStorage.setItem(`projeto-vida-${t.dataset.task}`, t.checked));
}

tarefas.forEach(tarefa => {
  tarefa.checked = localStorage.getItem(`projeto-vida-${tarefa.dataset.task}`) === 'true';
  tarefa.addEventListener('change', atualizarProgresso);
});

atualizarProgresso();
document.getElementById('ano').textContent = new Date().getFullYear();
